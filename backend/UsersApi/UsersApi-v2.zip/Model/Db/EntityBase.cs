﻿namespace UsersApi.Model.Db
{
    public abstract class EntityBase
    {
        public required Guid Id { get; set; }
    }
}
