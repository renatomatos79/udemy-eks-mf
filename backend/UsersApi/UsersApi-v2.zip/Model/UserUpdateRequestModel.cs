﻿namespace UsersApi.Model
{
    public class UserUpdateRequestModel
    {
        public required string Name { get; set; }
        public required string Email { get; set; }
    }
}
